# macOS-BlackSur
macOS Plymouth for Winsur Themes

#Creative Commons Zero v1.0 Universal

#This published content is only for teaching purposes and tests in a controlled environment! Free to share and edit as long as you leave the due credits from the original publication site: # https://github.com/TheHardsBrazil


How to install (from file manager)

    Download #macOS-BlackSur file .zip
    Extract here
    Open folder 
    Run install.sh

How to install (from terminal)

    Download #macOS-BlackSur file .zip
    Extract here
    Open folder 
    Right click (on an empty area)
    Click open in terminal
    Type command bellow
    
    sudo ./install.sh
    Done

Tested on

    Ubuntu 18.04 LTS
    Xubuntu 18.04
    Kubuntu 18.04
    Linux Mint 19

More questions? Please contact me.
